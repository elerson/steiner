This directory contains non-graphical demos of the 2D Mesh Generator
package. An old Qt3-based demos lies in the qt3/ sub-directory. The
Constrained Delaunay triangulation Qt4 demos has a 2D meshing feature that
demonstrates the  2D Mesh Generator package. See in the directory
demo/Triangulation_2/ of the CGAL tarball.
