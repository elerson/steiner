#ifndef POINT_DIALOG_CONFIG_H
#define POINT_DIALOG_CONFIG_H

#include <QtCore/qglobal.h>

#ifdef point_dialog_EXPORTS
#  define POINT_DIALOG_EXPORT Q_DECL_EXPORT
#else
#  define POINT_DIALOG_EXPORT Q_DECL_IMPORT
#endif

#endif // POINT_DIALOG_CONFIG_H
